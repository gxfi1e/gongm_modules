#!/bin/bash

# Define the base directory
base_dir="/home/gongm/my_ibamr_app/FIV_IIM/two_fiv_one_fixed"

# Simulation list file format: job_id SPU SPD UR
simulation_list="/home/gongm/job_scripts/simulation_list.txt"

# Define number of cores
num_cores=10

# Path to the post.py script
post_script="/home/gongm/job_scripts/postprocess_python_script/post.py"

post_dir="/home/gongm/job_scripts/postprocess_python_script"


# Array to hold job directories for sequential processing
declare -a job_dirs

# Temporary file for logging progress
progress_file="/tmp/simulation_progress.txt"
echo "" > $progress_file  # Clear previous content

xfce4-terminal -e "tail -f $progress_file"

total_jobs=0
# Read the simulation list and prepare directories
while IFS=' ' read -r job_id spu spd ur; do
  # Skip the header row
  if [[ $job_id =~ ^[0-9]+$ ]]; then
    # Create work directory named by parameters
    work_dir="${base_dir}/simulation_job_${spu}_${spd}_${ur}"
    mkdir -p "$work_dir"
    job_dirs+=("$work_dir")

    # Copy necessary files from the "Modules" directory
    cp "/home/gongm/my_ibamr_app/FIV_IIM/Modules/one_dof/two_fiv_one_fixed/"{example.cpp,example.d,example.o,input2d,main2d} "$work_dir"

    # Modify input2d file with SPU, SPD, and UR parameters
    sed -i "1,60s/SPU = [0-9]*\.[0-9]*/SPU = $spu/" "$work_dir/input2d"
    sed -i "1,60s/SPD = [0-9]*/SPD = $spd/" "$work_dir/input2d"
    sed -i "1,60s/UR = [0-9]*/UR = $ur/" "$work_dir/input2d"
    ((total_jobs++)) 
  fi
done < "$simulation_list"

# Counter for current job
current_job=0
# Sequentially execute simulations in prepared directories
for dir in "${job_dirs[@]}"; do
  echo "Starting simulation in $dir"
  ((current_job++))
  echo "Progress: [$current_job/$total_jobs] - Starting simulation in $dir" > $progress_file
  
  start_time=$(date +"%Y-%m-%d %H:%M:%S")
  echo "Start time: $start_time" >> $progress_file

  start_seconds=$(date -d "$start_time" +%s)

  # Change directory to work_dir and execute simulation
  cd "$dir"
  mpirun -np $num_cores ./main2d input2d
  result=$?

  end_time=$(date +"%Y-%m-%d %H:%M:%S")
  echo "End time: $end_time" >> $progress_file

  end_seconds=$(date -d "$end_time" +%s)
  duration_seconds=$((end_seconds - start_seconds))
  duration_hours=$(echo "$duration_seconds / 3600" | bc -l | awk '{printf "%.2f", $0}')
  core_hours=$(echo "$duration_hours * $num_cores" | bc -l | awk '{printf "%.2f", $0}')
  echo "Computation core_hours: $core_hours" >> $progress_file
  
  log_file="${dir}/simulation_log.txt"

  if [ $result -eq 0 ]; then
    echo "Simulation in $dir completed successfully." >> $progress_file
    status="Success"

    cp "$post_script" "$dir"
    python3 "$dir/post.py"
    post_result=$?

    if [ $post_result -eq 0 ]; then
      echo "Postprocessing in $dir completed successfully." >> $progress_file
      post_status="Success"
      
      # Now execute the origin.py script
     python3 "$post_dir/origin.py"
     origin_result=$?
     if [ $origin_result -eq 0 ]; then
     echo "Origin script executed successfully." >> $progress_file
     else
    echo "Origin script failed to execute." >> $progress_file
    fi
    else
      echo "Postprocessing in $dir failed." >> $progress_file
      post_status="Failure"
    fi
    else
    echo "Simulation in $dir failed." >> $progress_file
    status="Failure"
    post_status="Not run"
  fi
  

  # Create results directory if it doesn't exist
  [ ! -d "$dir/results" ] && mkdir "$dir/results"

  # Move .curve and .jpg files to results directory
  mv "$dir"/*.curve "$dir"/*.jpg "$dir/results"

  # Log the simulation data
  echo "$dir, $start_time, $end_time, $duration_hours hours, $num_cores cores, $core_hours core-hours, $status, Postprocessing: $post_status" >> "$log_file"

  # Ensure to return to the base directory before starting the next loop iteration
  cd "$base_dir"
done


echo "All simulations have been processed sequentially." >> $progress_file

