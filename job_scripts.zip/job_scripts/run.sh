#!/bin/bash




# Define directory array
directories=(
  "/home/gongm/my_ibamr_app/FIV_IIM/two_fiv_one_fixed/7/055"
  #"/home/gongm/my_ibamr_app/FIV_IIM/two_fiv_one_fixed/7/056"
  #"/home/gongm/my_ibamr_app/FIV_IIM/two_fiv_one_fixed/7/057"
  
  # Add more directories
)

# Define number of cores
num_cores=10

# Path for the simulation log file to be in the same directory as this script
log_file="$(dirname "$0")/simulation_log.txt"

# Path to the post.py script
post_script="/home/gongm/job_scripts/postprocess_python_script/post.py"

# Loop through directories and execute MPI commands
for dir in "${directories[@]}"; do
  echo "Starting simulation in $dir"
  start_time=$(date +"%Y-%m-%d %H:%M:%S")
  echo "Start time: $start_time"

  # Convert start time to seconds since epoch for calculation
  start_seconds=$(date -d "$start_time" +%s)

  cd "$dir"
  mpirun -np $num_cores ./main2d input2d
  result=$?

  end_time=$(date +"%Y-%m-%d %H:%M:%S")
  echo "End time: $end_time"

  # Convert end time to seconds since epoch for calculation
  end_seconds=$(date -d "$end_time" +%s)

  # Calculate duration in hours
  duration_seconds=$((end_seconds - start_seconds))
  duration_hours=$(echo "$duration_seconds / 3600" | bc -l | awk '{printf "%.2f", $0}')

  # Calculate core hours
  core_hours=$(echo "$duration_hours * $num_cores" | bc -l | awk '{printf "%.2f", $0}')

  if [ $result -eq 0 ]; then
    echo "Simulation in $dir completed successfully."
    status="Success"

    # Copy post.py script to simulation directory
    cp "$post_script" "$dir"

    # Run the post.py script
    python3 "$dir/post.py"
    post_result=$?

    if [ $post_result -eq 0 ]; then
      echo "Postprocessing in $dir completed successfully."
      post_status="Success"
    else
      echo "Postprocessing in $dir failed."
      post_status="Failure"
    fi
  else
    echo "Simulation in $dir failed."
    status="Failure"
    post_status="Not run"
  fi

  # Create results directory if it doesn't exist
  [ ! -d "$dir/results" ] && mkdir "$dir/results"

  # Move .curve files to results directory
  mv "$dir"/*.curve "$dir/results"
  
  # Move .jpg files to results directory
  mv "$dir"/*.jpg "$dir/results"
  # Log start and end time, duration, cores, core hours, status, and postprocessing status
  echo "$dir, $start_time, $end_time, $duration_hours hours, $num_cores cores, $core_hours core-hours, $status, Postprocessing: $post_status" >> "$log_file"

done

