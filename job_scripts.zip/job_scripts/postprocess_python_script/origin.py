import pandas as pd
import os
import shutil

# Define the base directory and post directory
base_dir = "/home/gongm/my_ibamr_app/FIV_IIM/two_fiv_one_fixed/"
post_dir = os.path.join(base_dir, "post")

# Ensure the post directory exists, if not, create it
os.makedirs(post_dir, exist_ok=True)

def is_target_file(filename):
    # Check if filename matches the expected pattern and format
    if filename.startswith('computation_results_') and filename.endswith('.csv'):
        parts = filename.replace('computation_results_', '').replace('.csv', '').split('_')
        if len(parts) == 3:
            try:
                [float(x) for x in parts]  # Validate parts are floats
                return True
            except ValueError:
                return False
    return False

# Copy files to the post directory if not already there
for root, dirs, files in os.walk(base_dir):
    for file in files:
        if is_target_file(file):
            source_filepath = os.path.join(root, file)
            destination_filepath = os.path.join(post_dir, file)
            if not os.path.exists(destination_filepath):  # Check if file already exists in destination
                shutil.copy2(source_filepath, destination_filepath)
                print(f"Copied: {source_filepath} to {destination_filepath}")

def parse_filename(filename):
    # Extract SPU, SPD, UR from filename
    parts = filename.replace('computation_results_', '').replace('.csv', '').split('_')
    return tuple(float(x) for x in parts)

def read_and_tag_file(filepath):
    # Read CSV and tag it with SPU, SPD, UR
    df = pd.read_csv(filepath)
    SPU, SPD, UR = parse_filename(os.path.basename(filepath))
    df['SP_U'] = SPU
    df['SP_D'] = SPD
    df['UR'] = UR
    return df

all_data = []

# Process files in the post directory, avoiding duplicates
for file in os.listdir(post_dir):
    if file.startswith('computation_results_') and file.endswith('.csv'):
        filepath = os.path.join(post_dir, file)
        df = read_and_tag_file(filepath)
        all_data.append(df)

# Concatenate, sort, and save all data frames
full_data = pd.concat(all_data, ignore_index=True)
sorted_data = full_data.sort_values(by=['SP_U', 'SP_D', 'UR'])
final_filepath = os.path.join(post_dir, 'final_results.csv')
sorted_data.to_csv(final_filepath, index=False)
print(f'Merged data written to {final_filepath}')

